﻿using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace SampleWebApplication.UnitTests
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void SampleUnitTest1()
        {
            Assert.AreEqual(1, 1);
        }

        [TestMethod]
        public void SampleUnitTest2()
        {
            Assert.AreEqual(1, 1);
        }

        [TestMethod]
        public void SampleUnitTest3()
        {
            Assert.AreEqual(1, 1);
        }
    }
}
